﻿using UnityEngine;
using System.Collections.Generic;

public class Node : MonoBehaviour {

    public Dictionary<string, string> adjacents;
    
	void Start()
    {
        adjacents = new Dictionary<string, string>();
	}

    public void add_node(string node_ref, string wire_ref)
    {

    }

    public void remove_node(string node_ref) { }

    public void swap_node(string new_node_ref, string new_wire_ref, string old_node_ref)
    {

    }

}
