﻿using System;
using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class Router : MonoBehaviour
{
    private int wire_index = 0;
    GlobalsManager gm;
    public GameObject nets_manager;

    Connection conn_dummy;
    List<string> route_types;
    int route_types_index = -1;
    Vector3 off_grid, grid_center;
    bool routing = false, route_started = false, end_trace = false;
    Vector3 last_position, start_position;
    Grid grid;
    public GameObject default_trace, current_trace, to_pt, from_pt, hit_pt, route_from, route_to;
    public string layer = "top";

    public string route_method = "square";
    private string route_direction;

    public Text display_text;

    private void Awake()
    {
        gm = GetComponent<GlobalsManager>();
        grid = GetComponent<Grid>();
        conn_dummy = new Connection();
        new Connection(new List<RefPin>(), new Wire());
        route_types = new List<string>() { "hsquare", "diag", "direct", "vsquare", "rdiag" };
        //update_route_type(0, route_type_text);
        //dummy_route();
        off_grid = new Vector3(-1000, 0, -1000);
        grid_center = new Vector3(0, 0, 0);
        last_position = off_grid;
        //update_route_type();
    }

    public void initialize_connections()
    {
        foreach (Transform child in nets_manager.transform)
        {
            List<GameObject> obj = new List<GameObject>();
            Dictionary<string, Vector3> pos = new Dictionary<string, Vector3>();
            //Debug.Log(child.gameObject.name);
            foreach (Transform gc in child)
            {
                obj.Add(gc.gameObject);
                pos.Add(gc.gameObject.name, gc.position);
                //Debug.Log(gc.gameObject.name + ", " + gc.position);
            }
            for(int i = 1; i < obj.Count; i++)
            {
                GameObject go = add_wire("airwire", gm.AIRWIRE_WIDTH, pos[obj[i].name], pos[obj[i - 1].name]);
                go.name = get_new_wire_name();
                go.transform.SetParent(child);
                go.GetComponent<Wire>().Connect("airwire", obj[i].name, obj[i - 1].name);
            }
        }
    }

    private string get_new_wire_name()
    {
        string name = "W" + wire_index++;
        return name;
    }

    private GameObject add_wire(string layer, float width, Vector3 from, Vector3 to)
    {
        try
        {
            GameObject wire = Instantiate(Resources.Load(layer, typeof(GameObject))) as GameObject;
            wire.transform.position = to + (from - to) / 2;
            wire.transform.up = (from - to);
            wire.transform.localScale = new Vector3(wire.transform.localScale.x, Vector3.Distance(from, to) / 2, wire.transform.localScale.z);
            return wire;
        }
        catch (Exception)
        {
            return null;
        }
    }

    private void dummy_route()
    {
        Debug.Log("Run " + get_route_type() + " route from " + route_from.transform.position + " to " + route_to.transform.position);
    }

    public string get_route_type()
    {
        return route_types[route_types_index];
    }

    public void update_route_type(int index)
    {
        route_types_index = index;
        //Debug.Log(route_types_index + " " + route_types[route_types_index]);
        display_text.text = route_types[route_types_index];
    }

    public void update_route_type()
    {
        route_types_index = ++route_types_index % route_types.Count;
        display_text.text = route_types[route_types_index];
    }

    public void update_route_style()
    {
        if (Input.GetMouseButtonDown(1))
        {
            //Debug.Log(route_types[route_types_index]);
            update_route_type();
            //dummy_route();
        }
    }
    public void handle_routing()
    {
        RaycastHit hitInfo;
        Ray ray;
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (route_started)
            {
                GameObject.Destroy(current_trace);
            }
            routing = false;
            route_started = false;
            Debug.Log("routing done.");
        }
        if (!routing)
        {
            if (Input.GetMouseButtonDown(0))    //prepare to route a trace
            {
                ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                if (Physics.Raycast(ray, out hitInfo))
                {
                    last_position = grid.GetNearestPointOnGrid(hitInfo.point);
                    routing = true;
                    route_started = false;
                    Debug.Log("starting a " + route_method + "trace route...");
                }
            }
        }
        else
        { //you are routing
            if (Input.GetMouseButtonDown(1))    //right-click to change layers
            {
                if (layer == "top") { layer = "bottom"; }
                else { layer = "top"; }
                Debug.Log("layer swap!");
            }
            else if (Input.GetMouseButtonDown(0))   //click to start a new segment
            {
                route_started = false;
                Debug.Log("starting another" + route_method + "trace route...");
                ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                if (Physics.Raycast(ray, out hitInfo))
                {
                    //last_position = grid.GetNearestPointOnGrid(hitInfo.point);  //get position
                }
            }
            else if (Input.GetMouseButtonDown(2))
            {
                //layer
            }
            if (!route_started) //start routing a trace
            {
                Debug.Log("laying trace!...");
                if (layer == "top")
                {
                    SetColor(current_trace, Color.red);
                }
                else if (layer == "bottom")
                {
                    SetColor(current_trace, Color.blue);
                }
                else
                {
                    Debug.Log("can't parse layer");
                }
                PlaceTrace(ref current_trace, default_trace, last_position);
                start_position = last_position;
                route_started = true;
            }
            else //continue a route operation
            {
                ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                if (Physics.Raycast(ray, out hitInfo))
                {
                    last_position = grid.GetNearestPointOnGrid(hitInfo.point);
                    Vector3 end_position = GetTraceVector(last_position, start_position, route_method);
                    RouteTrace(ref current_trace, start_position, end_position, hitInfo.point);
                    last_position = end_position;
                }
            }
        }
    }

    private bool SetColor(GameObject go, Color color)
    {
        try
        {
            default_trace.GetComponent<Renderer>().material.color = color;
            return true;
        }
        catch (Exception)
        {
            return false;
        }
        //return false;
    }

    private void RouteTrace(ref GameObject trace, Vector3 from, Vector3 to, Vector3 hit)
    {
        hit_pt.transform.position = new Vector3(hit.x, 0, hit.z);
        to_pt.transform.position = to;
        from_pt.transform.position = from;

        trace.transform.position = from + (to - from) / 2;
        trace.transform.localScale = new Vector3(trace.transform.localScale.x, trace.transform.localScale.y, Vector3.Distance(to, from));
        trace.transform.LookAt(to);
    }

    private Vector3 GetTraceVector(Vector3 position, Vector3 start_position, string route_method)
    {
        if (route_method == "square")
        {
            float lr = position.x - start_position.x;
            float ud = position.z - start_position.z;

            if (Mathf.Abs(lr) > Mathf.Abs(ud))
            {
                if (lr > 0)
                {
                    return start_position + new Vector3(lr, 0, 0);
                }
                else
                {
                    return start_position + new Vector3(lr, 0, 0);
                }
            }
            else
            {
                if (ud > 0)
                {
                    return start_position + new Vector3(0, 0, ud);
                }
                else
                {
                    return start_position + new Vector3(0, 0, ud);
                }
            }
        }
        else
        {
            Debug.Log("route method not recognized");
            return grid_center;
        }
        //return off_grid;
    }

    private void PlaceTrace(ref GameObject trace, GameObject route_prefab, Vector3 clickPoint)
    {
        var finalPosition = grid.GetNearestPointOnGrid(clickPoint);
        trace = GameObject.Instantiate(route_prefab) as GameObject;
        trace.transform.position = finalPosition;
        //GameObject.CreatePrimitive(PrimitiveType.Sphere).transform.position = nearPoint;
    }

}

