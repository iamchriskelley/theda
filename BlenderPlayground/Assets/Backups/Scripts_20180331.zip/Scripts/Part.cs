﻿using UnityEngine;
using System.Collections.Generic;
using System;

public class Part
{
    public string name { get; private set; }
    public string type { get; private set; }
    public string value { get; private set; }
    public string package { get; private set; }
    public Dictionary<string, string> attributes { get; private set; }
    public int pin_count { get; private set; }
    public List<string> pins { get; private set; }
    public List<string> pin_classes { get; private set; }
    //public int pad_count { get; private set; }
    //public List<string> pads { get; private set; }
    //public List<string> pad_classes { get; private set; }
    public Vector3 location { get; set; }
    public Vector3 rotation { get; set; }
    public RegMap regmap { get; set; }
    public List<string> error_log;

    public Part(string n, string t, string val, string pak, List<Attribute> attr, int pinc, List<string> pins_list, List<string> pins_cls, RegMap _regmap = null)
    {
        name = n;
        type = t;
        value = val;
        package = pak;
        pin_count = pinc;
        pins = pins_list;
        pin_classes = pins_cls ?? new List<String>();
        //pad_count = padc;
        //pads = pads_list;
        //pad_classes = pads_cls ?? new List<String>();
        regmap = _regmap;

        error_log = new List<string>();
        attributes = new Dictionary<string, string>();
        foreach (Attribute a in attr)
        {
            if (attributes.ContainsKey(a.k))
            {
                error_log.Add("Duplicate attribute key: " + a.k);
            }
            else
            {
                attributes.Add(a.k, a.v);
            }
        }
    }
}
