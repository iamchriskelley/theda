﻿using UnityEngine;
using System.Collections.Generic;

public class device_style : MonoBehaviour {
    Vector3 drag_start_point;
    Dictionary<string, string> pin_name;
    Dictionary<string, string> pin_type;
    public GameObject cam;
    public string name;

    void Awake() {
        cam = GameObject.Find("Main Camera");
        pin_name = new Dictionary<string, string>();
        pin_type = new Dictionary<string, string>();
        //attributes = new Dictionary<string, string> { {"foo","bar" } };
        if (gameObject.transform.FindChild("#overlay") != null){ gameObject.transform.FindChild("#overlay").gameObject.SetActive(false);}
    }

    void OnMouseDown()
    {
        drag_start_point = transform.position;
        Debug.Log("I, " + this.name + ", have been clicked at " + drag_start_point);
    }

    private void OnMouseOver()
    {
        //Debug.Log("Mouse over " + this.name + " at " + drag_start_point);
    }

    void OnCollisionEnter(Collision collision){Debug.Log("COLLISION DETECTED");}

    public void set_device(string _name, string device_class, string device_type, string protocol, string package, int pin_count, List<string> pin_names, List<string> pin_types) {
        name = _name;
        //Debug.Log(name + ", " + device_class + "," + device_type);
        for (int i = 1; i <= pin_count; i++)
        {
            //Debug.Log("pin" + i + ", " + pin_names[i - 1]);
            pin_name.Add("pin" + i, pin_names[i - 1]);
            pin_type.Add("pin" + i, pin_types[i - 1]);
        }

        //this.name = name;
        foreach (Transform child in GetComponentsInChildren<Transform>())
        {
            var n = child.name;
            if (pin_type.ContainsKey(n))
            {
                child.GetComponent<Renderer>().material.color = cam.GetComponent<DeviceManager>().getPinColor(pin_type[n]);
            }
            //else if (n != this.name){Debug.Log("pin not recognized: " + n);}
        }
    }

}