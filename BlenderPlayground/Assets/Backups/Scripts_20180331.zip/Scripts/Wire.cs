﻿using System;
using UnityEngine;
using System.Collections.Generic;

public class Wire : MonoBehaviour {
    Material mat;
    Color highlight_color = new Color(0.9f, 0.36f, 0); //orange
    Color normal_color;
    public string ref_des;
    public float width;
    public string layer;
    string node1, node2;
    Dictionary<string, Vector3> nodes;

    void Awake()
    {
        nodes = new Dictionary<string, Vector3>();
        mat = gameObject.GetComponent<Renderer>().material;
        normal_color = mat.color;
    }

    public bool Connect(string lyr, string n1, string n2)
    {
        //try
        //{
            layer = lyr;
            GameObject g1 = GameObject.Find(n1);
            GameObject g2 = GameObject.Find(n2);
            //Debug.Log("NAME = " + g2.name + " " + (g1 == null || g2 == null));
            if (g1 == null || g2 == null) return false;
            node1 = n1;
            node2 = n2;
            nodes.Add(g1.name, g1.transform.position);
            nodes.Add(g2.name, g2.transform.position);
            Debug.Log("CONNECTED");
            return true;
        //}
        //catch (Exception)
        //{
        //    return false;
        //}
    }

    void OnMouseDown()
    {
        Debug.Log("Hi, I'm " + gameObject.name);
        Debug.Log("My neighbors are " + node1 + " at " + nodes[node1]);// + " and " + node2 + " at " + nodes[node2]);
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit = new RaycastHit();
        if (Physics.Raycast(ray, out hit))
        {
            Debug.Log("You clicked me at " + hit.point);
            float d1 = Vector3.Distance(nodes[node1], hit.point);
            float d2 = Vector3.Distance(nodes[node2], hit.point);
            string which = node1;
            if (d2 < d1) which = node2;
            Debug.Log("That is closer to " + which);
            if (layer == "airwire")
            {
                Debug.Log("Begin routing trace from " + which + " to clicked point");
            }
        }
    }

    void OnMouseOver()
    {
        mat.color = highlight_color;
    }

    void OnMouseExit()
    {
        mat.color = normal_color;
    }

}
