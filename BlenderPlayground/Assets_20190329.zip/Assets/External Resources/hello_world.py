import bpy
print("hello world")
object = bpy.data.objects['Body1']
object.select = True
